var searchData=
[
  ['i2c_5fdirection_5ft',['i2c_direction_t',['../a00030.html#gab49c827b45635206f06e5737606e4611',1,'fsl_i2c.h']]],
  ['i2c_5fslave_5faddress_5fmode_5ft',['i2c_slave_address_mode_t',['../a00030.html#gac21e18657981bd7861f2ac5ebc5f633b',1,'fsl_i2c.h']]],
  ['i2c_5fslave_5ftransfer_5fevent_5ft',['i2c_slave_transfer_event_t',['../a00030.html#gac53e5c96a2eed1b5a95b7d84be48f4ac',1,'fsl_i2c.h']]]
];
