var searchData=
[
  ['vref_5fbuffer_5fmode_5ft',['vref_buffer_mode_t',['../a00069.html#ga791fe2db52ad2d1e359ac294a00e0c7f',1,'fsl_vref.h']]]
];
