var searchData=
[
  ['vref_5fconfig_5ft',['vref_config_t',['../a00069.html#a00458',1,'']]]
];
