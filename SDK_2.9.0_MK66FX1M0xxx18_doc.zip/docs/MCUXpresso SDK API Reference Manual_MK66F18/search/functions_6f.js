var searchData=
[
  ['osc_5fsetcapload',['OSC_SetCapLoad',['../a00037.html#ga54df59d291f2c23beae934a8fb8d9867',1,'fsl_clock.h']]],
  ['osc_5fsetextrefclkconfig',['OSC_SetExtRefClkConfig',['../a00037.html#ga49bf2e509c691697a70f57580d5705c1',1,'fsl_clock.h']]]
];
