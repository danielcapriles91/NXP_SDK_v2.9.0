var searchData=
[
  ['i2c_5fmaster_5fedma_5ftransfer_5fcallback_5ft',['i2c_master_edma_transfer_callback_t',['../a00031.html#ga8e6dcec2d47eae5e1e5e2bb6c40b7e57',1,'fsl_i2c_edma.h']]],
  ['i2c_5fmaster_5ftransfer_5fcallback_5ft',['i2c_master_transfer_callback_t',['../a00030.html#ga1c6e059706357c744c165ce7ecd1c185',1,'fsl_i2c.h']]],
  ['i2c_5fslave_5ftransfer_5fcallback_5ft',['i2c_slave_transfer_callback_t',['../a00030.html#ga974310ded85af5ef341811d542db650c',1,'fsl_i2c.h']]]
];
