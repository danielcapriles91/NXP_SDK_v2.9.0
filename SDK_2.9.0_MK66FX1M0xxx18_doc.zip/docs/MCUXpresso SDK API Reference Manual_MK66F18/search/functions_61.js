var searchData=
[
  ['adc16_5fclearstatusflags',['ADC16_ClearStatusFlags',['../a00008.html#ga59f064511092ccd4f4923d3c2117f0b6',1,'fsl_adc16.h']]],
  ['adc16_5fdeinit',['ADC16_Deinit',['../a00008.html#ga11a137d2238d13fb42595e2ad12f26b4',1,'fsl_adc16.h']]],
  ['adc16_5fdoautocalibration',['ADC16_DoAutoCalibration',['../a00008.html#ga0750bb2a5a9b7fa9eef39fa74574de30',1,'fsl_adc16.h']]],
  ['adc16_5fenabledma',['ADC16_EnableDMA',['../a00008.html#gaeb2aa303ede3f6ab26e5006b34c23da6',1,'fsl_adc16.h']]],
  ['adc16_5fenablehardwaretrigger',['ADC16_EnableHardwareTrigger',['../a00008.html#gae7bc179724ced687fb92e995dba74fbc',1,'fsl_adc16.h']]],
  ['adc16_5fgetchannelconversionvalue',['ADC16_GetChannelConversionValue',['../a00008.html#gad6b57658162f3e5d4d75fc8d793c06ba',1,'fsl_adc16.h']]],
  ['adc16_5fgetchannelstatusflags',['ADC16_GetChannelStatusFlags',['../a00008.html#ga95ed174dd644d1afbdec9771b8c42c94',1,'fsl_adc16.h']]],
  ['adc16_5fgetdefaultconfig',['ADC16_GetDefaultConfig',['../a00008.html#ga5987063a1033f2efee690bd322895e98',1,'fsl_adc16.h']]],
  ['adc16_5fgetstatusflags',['ADC16_GetStatusFlags',['../a00008.html#ga7bdf0da20ceb4528f29088d63f0e2120',1,'fsl_adc16.h']]],
  ['adc16_5finit',['ADC16_Init',['../a00008.html#ga63c52882edbac67d4209576c0577b944',1,'fsl_adc16.h']]],
  ['adc16_5fsetchannelconfig',['ADC16_SetChannelConfig',['../a00008.html#ga7b953a868efa27473910b72d7f80287c',1,'fsl_adc16.h']]],
  ['adc16_5fsetchannelmuxmode',['ADC16_SetChannelMuxMode',['../a00008.html#ga544e53acf6753f8572451405adcf1f2c',1,'fsl_adc16.h']]],
  ['adc16_5fsethardwareaverage',['ADC16_SetHardwareAverage',['../a00008.html#gad2f871750e9c495a5f0dfaf45e9a6fb6',1,'fsl_adc16.h']]],
  ['adc16_5fsethardwarecompareconfig',['ADC16_SetHardwareCompareConfig',['../a00008.html#ga42c2828593acc22a8b8961efbbbcf7a4',1,'fsl_adc16.h']]],
  ['adc16_5fsetoffsetvalue',['ADC16_SetOffsetValue',['../a00008.html#ga3125b28b69c6cbffc7447ae2526ca1d6',1,'fsl_adc16.h']]]
];
