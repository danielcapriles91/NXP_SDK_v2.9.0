var searchData=
[
  ['nbytes',['NBYTES',['../a00019.html#ada2a3af3cbf20ed38a3669c963d49f7d',1,'edma_tcd_t::NBYTES()'],['../a00018.html#a30d164e18ab9baecaf60426d23d66813',1,'_dspi_master_edma_handle::nbytes()'],['../a00018.html#a67a3121f2b054acd94e8557770d979c2',1,'_dspi_slave_edma_handle::nbytes()'],['../a00031.html#a12372a02e497b34e78291de9718d9686',1,'_i2c_master_edma_handle::nbytes()'],['../a00035.html#a7ffb3be259d932a6a9f7e86aed4cc790',1,'_lpuart_edma_handle::nbytes()'],['../a00048.html#a061d53e53af802d59eca8bc3171297ce',1,'sai_edma_handle::nbytes()'],['../a00067.html#a42e9b4098a1a5bc1891aad20e1e36a8a',1,'_uart_edma_handle::nbytes()']]],
  ['next',['next',['../a00063.html#a1469c2b8d47a70c59f28af8ec05fe2cf',1,'sysmpu_config_t']]],
  ['nextchanedgemode',['nextChanEdgeMode',['../a00028.html#af64561d78c1d94a7d7106785dce6da7c',1,'ftm_dual_edge_capture_param_t::nextChanEdgeMode()'],['../a00064.html#a700c20e23231ba39cf5413dde606d5fb',1,'tpm_dual_edge_capture_param_t::nextChanEdgeMode()']]],
  ['nextswapblockstatus',['nextSwapBlockStatus',['../a00027.html#aafa39112d05ace3cbd1754e30a9cc7c5',1,'ftfx_swap_state_config_t']]],
  ['nointeralalign',['noInteralAlign',['../a00039.html#a306fbd3a3215259f9b380f8e8423f172',1,'mmc_card_t::noInteralAlign()'],['../a00049.html#a089143022f4fcf62251935db4ee7e996',1,'sd_card_t::noInteralAlign()']]],
  ['nointernalalign',['noInternalAlign',['../a00051.html#aa3a92263c58ded5911a0c0bce688352f',1,'_sdio_card']]],
  ['notifytype',['notifyType',['../a00040.html#a2ca3b1a52e315e072a8ab48fcc1dd62a',1,'notifier_notification_block_t']]],
  ['nscn',['nscn',['../a00065.html#a9bac8b732f3b1ee8ef626cc72e589fb0',1,'tsi_config_t']]],
  ['numblockconfig',['numBlockConfig',['../a00054.html#a4455ff23450c2be6c5ae2647cacdb095',1,'sdramc_config_t']]]
];
