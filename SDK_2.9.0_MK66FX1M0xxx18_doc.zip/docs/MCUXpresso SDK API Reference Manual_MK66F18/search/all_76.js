var searchData=
[
  ['value',['value',['../a00033.html#a1901c7ceff05610d3e454ebef8f0fd0b',1,'lptmr_config_t']]],
  ['value1',['value1',['../a00008.html#a6b1b62278e6642bd6ebb1f89795585b6',1,'adc16_hardware_compare_config_t']]],
  ['value2',['value2',['../a00008.html#adbbb6304a3dc60880f6f39b3104313c5',1,'adc16_hardware_compare_config_t']]],
  ['vdiv',['vdiv',['../a00037.html#ab5b4c77a93577e105a8f234e1473b43c',1,'mcg_pll_config_t']]],
  ['vendorversion',['vendorVersion',['../a00050.html#adf1780607151276c66a01c0e6f34159b',1,'sdhc_capability_t']]],
  ['version',['version',['../a00049.html#a23b8ed9688825316750d697b524c7d18',1,'sd_card_t']]],
  ['versionidstart',['versionIdStart',['../a00027.html#a0cb9306816476d64fc5dad11ff627b8f',1,'ftfx_ifr_desc_t']]],
  ['voltselect',['voltSelect',['../a00043.html#a668031bb79d615e9d1edb74a4ed18f83',1,'pmc_low_volt_detect_config_t::voltSelect()'],['../a00043.html#a4f0dc0e27741e2dcc4d3c3064f8352e6',1,'pmc_low_volt_warning_config_t::voltSelect()']]],
  ['vref_3a_20voltage_20reference_20driver',['VREF: Voltage Reference Driver',['../a00069.html',1,'']]],
  ['vref_5fbuffer_5fmode_5ft',['vref_buffer_mode_t',['../a00069.html#ga791fe2db52ad2d1e359ac294a00e0c7f',1,'fsl_vref.h']]],
  ['vref_5fclocks',['VREF_CLOCKS',['../a00037.html#gadada275d718274d382e3488eebb46d04',1,'fsl_clock.h']]],
  ['vref_5fconfig_5ft',['vref_config_t',['../a00069.html#a00458',1,'']]],
  ['vref_5fdeinit',['VREF_Deinit',['../a00069.html#ga19cab0650f351da4be7ab2ac0d313d8d',1,'fsl_vref.h']]],
  ['vref_5fgetdefaultconfig',['VREF_GetDefaultConfig',['../a00069.html#ga75fd76b8991bf283c6bfda6e9503433c',1,'fsl_vref.h']]],
  ['vref_5fgettrimval',['VREF_GetTrimVal',['../a00069.html#gab6fc89e608c1ddb5b323ad8d992ccbbb',1,'fsl_vref.h']]],
  ['vref_5finit',['VREF_Init',['../a00069.html#gafa6d07d12cf6fb74c84b995f35a57c21',1,'fsl_vref.h']]],
  ['vref_5fsettrimval',['VREF_SetTrimVal',['../a00069.html#gac298cc63090a16123d466eb8efc9cfe3',1,'fsl_vref.h']]]
];
