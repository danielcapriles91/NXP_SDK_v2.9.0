var searchData=
[
  ['vref_5fdeinit',['VREF_Deinit',['../a00069.html#ga19cab0650f351da4be7ab2ac0d313d8d',1,'fsl_vref.h']]],
  ['vref_5fgetdefaultconfig',['VREF_GetDefaultConfig',['../a00069.html#ga75fd76b8991bf283c6bfda6e9503433c',1,'fsl_vref.h']]],
  ['vref_5fgettrimval',['VREF_GetTrimVal',['../a00069.html#gab6fc89e608c1ddb5b323ad8d992ccbbb',1,'fsl_vref.h']]],
  ['vref_5finit',['VREF_Init',['../a00069.html#gafa6d07d12cf6fb74c84b995f35a57c21',1,'fsl_vref.h']]],
  ['vref_5fsettrimval',['VREF_SetTrimVal',['../a00069.html#gac298cc63090a16123d466eb8efc9cfe3',1,'fsl_vref.h']]]
];
