var searchData=
[
  ['uart_5fedma_5ftransfer_5fcallback_5ft',['uart_edma_transfer_callback_t',['../a00067.html#ga1fbe483dd5c3f3d55eb6d15b1b9582da',1,'fsl_uart_edma.h']]],
  ['uart_5ftransfer_5fcallback_5ft',['uart_transfer_callback_t',['../a00066.html#gaf164fa4e12ff8a3e3f3997512001e007',1,'fsl_uart.h']]]
];
