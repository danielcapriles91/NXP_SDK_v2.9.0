var searchData=
[
  ['pdb_3a_20programmable_20delay_20block',['PDB: Programmable Delay Block',['../a00041.html',1,'']]],
  ['pit_3a_20periodic_20interrupt_20timer',['PIT: Periodic Interrupt Timer',['../a00042.html',1,'']]],
  ['pmc_3a_20power_20management_20controller',['PMC: Power Management Controller',['../a00043.html',1,'']]],
  ['port_3a_20port_20control_20and_20interrupts',['PORT: Port Control and Interrupts',['../a00044.html',1,'']]]
];
