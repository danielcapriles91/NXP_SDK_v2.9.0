var searchData=
[
  ['rcm_3a_20reset_20control_20module_20driver',['RCM: Reset Control Module Driver',['../a00045.html',1,'']]],
  ['rnga_3a_20random_20number_20generator_20accelerator_20driver',['RNGA: Random Number Generator Accelerator Driver',['../a00246.html',1,'']]],
  ['rtc_3a_20real_20time_20clock',['RTC: Real Time Clock',['../a00046.html',1,'']]]
];
