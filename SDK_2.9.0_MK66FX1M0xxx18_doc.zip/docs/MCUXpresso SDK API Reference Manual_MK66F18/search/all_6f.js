var searchData=
[
  ['ocr',['ocr',['../a00039.html#a0b3899f0be098f696fd5bc212d4b597e',1,'mmc_card_t::ocr()'],['../a00049.html#a4dfdb06355545a94755d7b7b8b8bb708',1,'sd_card_t::ocr()'],['../a00051.html#a493c409455409991a2af4ae08e31b386',1,'_sdio_card::ocr()'],['../a00055.html#a944b85aa51494ed8de4761f7ec0528a4',1,'sdspi_card_t::ocr()']]],
  ['opendrainenable',['openDrainEnable',['../a00044.html#ab14e3ebfd65f52da449b8afa5d3f785b',1,'port_pin_config_t']]],
  ['operationvoltage',['operationVoltage',['../a00049.html#aef60a9196a9789f243660bb76f3a0ef2',1,'sd_card_t::operationVoltage()'],['../a00051.html#a7aecd4677ec222958c8daad36033933d',1,'_sdio_card::operationVoltage()']]],
  ['osc_5fconfig_5ft',['osc_config_t',['../a00037.html#a00375',1,'']]],
  ['osc_5fmode_5ft',['osc_mode_t',['../a00037.html#ga6910de50c208447883676a41cd6971f0',1,'fsl_clock.h']]],
  ['osc_5fsetcapload',['OSC_SetCapLoad',['../a00037.html#ga54df59d291f2c23beae934a8fb8d9867',1,'fsl_clock.h']]],
  ['osc_5fsetextrefclkconfig',['OSC_SetExtRefClkConfig',['../a00037.html#ga49bf2e509c691697a70f57580d5705c1',1,'fsl_clock.h']]],
  ['oscer_5fconfig_5ft',['oscer_config_t',['../a00037.html#a00376',1,'']]],
  ['oscerconfig',['oscerConfig',['../a00037.html#afcee667e6296c809c8132de8a2c61c6e',1,'osc_config_t']]],
  ['oscsel',['oscsel',['../a00037.html#a3046511de09fc1ed5b0fe8310dfab6d0',1,'mcg_config_t']]],
  ['outputclock_5fhz',['outputClock_HZ',['../a00015.html#aa437baa5261123cd810488ac65e201dd',1,'da7212_pll_config_t::outputClock_HZ()'],['../a00071.html#ab58ab790fa57e24806ef762dc9cbbbae',1,'wm8904_fll_config_t::outputClock_HZ()']]],
  ['outputlogic',['outputLogic',['../a00029.html#a9d37ffd9a2943f10a91095759bd52da5',1,'gpio_pin_config_t']]]
];
