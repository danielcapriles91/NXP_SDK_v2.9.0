var searchData=
[
  ['i2c_5fmaster_5fconfig_5ft',['i2c_master_config_t',['../a00030.html#a00354',1,'']]],
  ['i2c_5fmaster_5ftransfer_5ft',['i2c_master_transfer_t',['../a00030.html#a00355',1,'']]],
  ['i2c_5fslave_5fconfig_5ft',['i2c_slave_config_t',['../a00030.html#a00356',1,'']]],
  ['i2c_5fslave_5ftransfer_5ft',['i2c_slave_transfer_t',['../a00030.html#a00357',1,'']]]
];
