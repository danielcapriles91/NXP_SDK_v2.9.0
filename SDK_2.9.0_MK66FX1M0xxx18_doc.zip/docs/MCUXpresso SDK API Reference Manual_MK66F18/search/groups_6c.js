var searchData=
[
  ['llwu_3a_20low_2dleakage_20wakeup_20unit_20driver',['LLWU: Low-Leakage Wakeup Unit Driver',['../a00032.html',1,'']]],
  ['lmem_3a_20local_20memory_20controller_20cache_20control_20driver',['LMEM: Local Memory Controller Cache Control Driver',['../a00244.html',1,'']]],
  ['lptmr_3a_20low_2dpower_20timer',['LPTMR: Low-Power Timer',['../a00033.html',1,'']]],
  ['lpuart_3a_20_20low_20power_20universal_20asynchronous_20receiver_2ftransmitter_20driver',['LPUART:  Low Power Universal Asynchronous Receiver/Transmitter Driver',['../a00245.html',1,'']]],
  ['lpuart_5fcmsis_5fdriver',['Lpuart_cmsis_driver',['../a00256.html',1,'']]],
  ['lpuart_20driver',['LPUART Driver',['../a00034.html',1,'']]],
  ['lpuart_5fedma_5fdriver',['Lpuart_edma_driver',['../a00035.html',1,'']]],
  ['lpuart_5ffreertos_5fdriver',['Lpuart_freertos_driver',['../a00036.html',1,'']]]
];
