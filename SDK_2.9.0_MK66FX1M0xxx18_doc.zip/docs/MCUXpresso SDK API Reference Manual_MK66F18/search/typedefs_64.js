var searchData=
[
  ['dspi_5fmaster_5fedma_5ftransfer_5fcallback_5ft',['dspi_master_edma_transfer_callback_t',['../a00018.html#gab42b9728993882f00f22e122c73848e4',1,'fsl_dspi_edma.h']]],
  ['dspi_5fmaster_5ftransfer_5fcallback_5ft',['dspi_master_transfer_callback_t',['../a00017.html#gad191922bda6ac07f95f241a67eb52f48',1,'fsl_dspi.h']]],
  ['dspi_5fslave_5fedma_5ftransfer_5fcallback_5ft',['dspi_slave_edma_transfer_callback_t',['../a00018.html#ga0299bb3ddcaa8ec04c8bac111c24aa0e',1,'fsl_dspi_edma.h']]],
  ['dspi_5fslave_5ftransfer_5fcallback_5ft',['dspi_slave_transfer_callback_t',['../a00017.html#ga0c9ef1b6a6d8034b5e47b8310f2d52dc',1,'fsl_dspi.h']]]
];
