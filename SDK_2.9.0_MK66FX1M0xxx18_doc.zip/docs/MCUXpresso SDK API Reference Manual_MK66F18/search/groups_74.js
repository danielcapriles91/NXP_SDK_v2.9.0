var searchData=
[
  ['tpm_3a_20timer_20pwm_20module',['TPM: Timer PWM Module',['../a00064.html',1,'']]],
  ['tsi_3a_20touch_20sensing_20input',['TSI: Touch Sensing Input',['../a00065.html',1,'']]]
];
