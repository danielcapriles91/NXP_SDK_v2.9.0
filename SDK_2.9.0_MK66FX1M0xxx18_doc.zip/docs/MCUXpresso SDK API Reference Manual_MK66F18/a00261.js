var a00261 =
[
    [ "HAL_CODEC_HANDLER_SIZE", "a00261.html#gabcc76de089dc2c9415a9c9d1df7f1d8e", null ],
    [ "_codec_type", "a00261.html#gab04db8cf1054dbe730016a5e3ddc3aef", [
      [ "kCODEC_CS42888", "a00264.html#ggab04db8cf1054dbe730016a5e3ddc3aefae667850df8261ea1e8c02201e1ccafee", null ],
      [ "kCODEC_DA7212", "a00264.html#ggab04db8cf1054dbe730016a5e3ddc3aefa533359b62306ff77d6cd4a6aeaf075ab", null ],
      [ "kCODEC_SGTL5000", "a00264.html#ggab04db8cf1054dbe730016a5e3ddc3aefa870028cfe305a220c90a187029ae3408", null ],
      [ "kCODEC_WM8904", "a00264.html#ggab04db8cf1054dbe730016a5e3ddc3aefacb2ee31cd4ee06712e3cf445e12cb389", null ]
    ] ],
    [ "HAL_CODEC_Init", "a00261.html#gaacaca021f47a8174ea25b69f8fceff5f", null ],
    [ "HAL_CODEC_Deinit", "a00261.html#ga6385e5d828698f51a25a741865cca2b2", null ],
    [ "HAL_CODEC_SetFormat", "a00261.html#gaabd166855f5c09d66f1c5c3d379a635d", null ],
    [ "HAL_CODEC_SetVolume", "a00261.html#ga51abed9ee2f12e9deecc772ec5d48ab5", null ],
    [ "HAL_CODEC_SetMute", "a00261.html#ga7fe3089ce2bacf817634df308f2a19e5", null ],
    [ "HAL_CODEC_SetPower", "a00261.html#gae3e89b179a83526dfaa69b0c4a665b77", null ],
    [ "HAL_CODEC_SetRecord", "a00261.html#gac22308d0062c5f138f52c2538e34319b", null ],
    [ "HAL_CODEC_SetRecordChannel", "a00261.html#gaaff43aee0fe7a998631c7ab79f44b1c7", null ],
    [ "HAL_CODEC_SetPlay", "a00261.html#gac1a980fbd520ed672bfa6d4cdb6037d1", null ],
    [ "HAL_CODEC_ModuleControl", "a00261.html#gab9b1d4ab9fd26f43be6d47ca575a3d0c", null ]
];