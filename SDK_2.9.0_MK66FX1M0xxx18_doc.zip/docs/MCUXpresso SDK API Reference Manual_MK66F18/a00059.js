var a00059 =
[
    [ "sgtl_audio_format_t", "a00059.html#a00435", [
      [ "mclk_HZ", "a00059.html#ae0edadf6baf0a743e4765421ad2abc3f", null ],
      [ "sampleRate", "a00059.html#a47b2d7178ab3a15a56b8972b2d2eac29", null ],
      [ "bitWidth", "a00059.html#a78334148115e196b31db9b1a302a4941", null ],
      [ "sclkEdge", "a00059.html#a9cdfd73fb1b74ee97d94e2e183af5a00", null ]
    ] ],
    [ "sgtl_config_t", "a00059.html#a00436", [
      [ "route", "a00059.html#a8c4ed2bb6162b218a0aa8077d9bab4aa", null ],
      [ "bus", "a00059.html#a1991cd986722d22c8964f08bc9d8c21d", null ],
      [ "master_slave", "a00059.html#a4daf6a63ca5b405aac9332ca477c3501", null ],
      [ "format", "a00059.html#af41c4ad8e8dfb29b4fde75d76f9f43c8", null ],
      [ "slaveAddress", "a00059.html#abdee01c708fa6a6beaf93e371347c590", null ],
      [ "i2cConfig", "a00059.html#a0552d0239f157964cdc500d73350d11d", null ]
    ] ],
    [ "sgtl_handle_t", "a00059.html#a00437", [
      [ "config", "a00059.html#a2187719e2579f70c815eff00bd8d7b98", null ],
      [ "i2cHandle", "a00059.html#aee64ef7e3a76d06780a73c63d68d2a98", null ]
    ] ],
    [ "FSL_SGTL5000_DRIVER_VERSION", "a00059.html#gacb25f9b960a10309cc4b9b2cb0f0c063", null ],
    [ "CHIP_ID", "a00059.html#gab0aa3e54cd2934b67b9882957456c391", null ],
    [ "SGTL5000_HEADPHONE_MAX_VOLUME_VALUE", "a00059.html#ga5b4c16e15a52d1a940e4d47bf3574752", null ],
    [ "SGTL5000_I2C_ADDR", "a00059.html#ga58ceb20f920b2b006c74eeeae992830a", null ],
    [ "SGTL_I2C_HANDLER_SIZE", "a00059.html#ga5a006451f9e990a4d3255ed7265ff1ad", null ],
    [ "SGTL_I2C_BITRATE", "a00059.html#ga7bf82c8b0e6415457b6f42f50af4230d", null ],
    [ "sgtl_module_t", "a00059.html#gaf78d5250d200a4cc76a60dcff249a4d3", [
      [ "kSGTL_ModuleADC", "a00059.html#ggaf78d5250d200a4cc76a60dcff249a4d3aeff780e31f47de5bd4ae4f7c2247a943", null ],
      [ "kSGTL_ModuleDAC", "a00059.html#ggaf78d5250d200a4cc76a60dcff249a4d3ac97955a1a57467c8a7a93629468c0ae5", null ],
      [ "kSGTL_ModuleDAP", "a00059.html#ggaf78d5250d200a4cc76a60dcff249a4d3a6db304a2a1838b8733167b535efd1cc6", null ],
      [ "kSGTL_ModuleHP", "a00059.html#ggaf78d5250d200a4cc76a60dcff249a4d3a7c3ca8ea568a0109f5858469734f1f22", null ],
      [ "kSGTL_ModuleI2SIN", "a00059.html#ggaf78d5250d200a4cc76a60dcff249a4d3a5eec6607385362c2f1f67574f98bab7f", null ],
      [ "kSGTL_ModuleI2SOUT", "a00059.html#ggaf78d5250d200a4cc76a60dcff249a4d3ad549fbd25f776da2e48029e7defb136d", null ],
      [ "kSGTL_ModuleLineIn", "a00059.html#ggaf78d5250d200a4cc76a60dcff249a4d3a3cf24e3ca184744b13ce10adb648afcd", null ],
      [ "kSGTL_ModuleLineOut", "a00059.html#ggaf78d5250d200a4cc76a60dcff249a4d3a04e0f93df81aacf8114308d95703248f", null ],
      [ "kSGTL_ModuleMicin", "a00059.html#ggaf78d5250d200a4cc76a60dcff249a4d3a4d7e27445f7842c7d420a3621ac73e72", null ]
    ] ],
    [ "sgtl_route_t", "a00059.html#ga78ef5545b50946b6d168203283c20820", [
      [ "kSGTL_RouteBypass", "a00059.html#gga78ef5545b50946b6d168203283c20820a1ea39c5bbafcc616613e8755b70573e9", null ],
      [ "kSGTL_RoutePlayback", "a00059.html#gga78ef5545b50946b6d168203283c20820ad379b8e67ddbbb27bc44c6d6f3cf7c0e", null ],
      [ "kSGTL_RoutePlaybackandRecord", "a00059.html#gga78ef5545b50946b6d168203283c20820ae11f7c67b7d1ab7e4dce3d927be7da00", null ],
      [ "kSGTL_RoutePlaybackwithDAP", "a00059.html#gga78ef5545b50946b6d168203283c20820ae79c7286d52a67b618e4e23a1f1306b6", null ],
      [ "kSGTL_RoutePlaybackwithDAPandRecord", "a00059.html#gga78ef5545b50946b6d168203283c20820a53052344996dc1f90cf6457e2b81eb18", null ],
      [ "kSGTL_RouteRecord", "a00059.html#gga78ef5545b50946b6d168203283c20820a0c28a072be0500106b9b32a16f05f000", null ]
    ] ],
    [ "sgtl_protocol_t", "a00059.html#ga9bd346f7776a687fe345e336127e5426", [
      [ "kSGTL_BusI2S", "a00059.html#gga9bd346f7776a687fe345e336127e5426ab56aded98ae08bb3dd4c431e036eb9b7", null ],
      [ "kSGTL_BusLeftJustified", "a00059.html#gga9bd346f7776a687fe345e336127e5426a99d80a1bbb2ca42f8d8b9ded7d0fe156", null ],
      [ "kSGTL_BusRightJustified", "a00059.html#gga9bd346f7776a687fe345e336127e5426a742196d31e1ede4eb6d0b1bd6afcdc50", null ],
      [ "kSGTL_BusPCMA", "a00059.html#gga9bd346f7776a687fe345e336127e5426aae65c2ae38164483661ce81683e2cf6d", null ],
      [ "kSGTL_BusPCMB", "a00059.html#gga9bd346f7776a687fe345e336127e5426a165348d47026247f859a40813f449cfd", null ],
      [ "kSGTL_HeadphoneLeft", "a00059.html#gga73c53bacb25588538843a1dcfe5f382ba4438d9d23b966a384697ac3959ec180c", null ],
      [ "kSGTL_HeadphoneRight", "a00059.html#gga73c53bacb25588538843a1dcfe5f382ba7c3a64195b071d4d17957f2de39a45a7", null ],
      [ "kSGTL_LineoutLeft", "a00059.html#gga73c53bacb25588538843a1dcfe5f382baea79ecce1f81bf12000fcf64671502ea", null ],
      [ "kSGTL_LineoutRight", "a00059.html#gga73c53bacb25588538843a1dcfe5f382babe25d4199f174f03f271a2ac335904bb", null ],
      [ "kSGTL_RecordSourceLineIn", "a00059.html#gga26e1124d33b4acdb532c49f6498df549a358889525fbd4a6d5998c17a2382ac16", null ],
      [ "kSGTL_RecordSourceMic", "a00059.html#gga26e1124d33b4acdb532c49f6498df549a3c1289899ca6bdbe2ee24346890a19e2", null ],
      [ "kSGTL_PlaySourceLineIn", "a00059.html#gga7ee8d0f117a79ca7eb1e0076a9182bcbad99308b50ee139be94b584a66d999caf", null ],
      [ "kSGTL_PlaySourceDAC", "a00059.html#gga7ee8d0f117a79ca7eb1e0076a9182bcba9c7fa540632ee8e4c733fb4ccebc8601", null ]
    ] ],
    [ "sgtl_sclk_edge_t", "a00059.html#ga1d2c82787cda907a0ac8646e11171db8", [
      [ "kSGTL_SclkValidEdgeRising", "a00059.html#gga1d2c82787cda907a0ac8646e11171db8aa89baee03025ca12e2fd8eb03909724c", null ],
      [ "kSGTL_SclkValidEdgeFailling", "a00059.html#gga1d2c82787cda907a0ac8646e11171db8a0e8f446d380d7f3c859b68ffe5a64a08", null ]
    ] ],
    [ "SGTL_Init", "a00059.html#ga5dd1b8225b23f6e47c4abed5bf74709f", null ],
    [ "SGTL_SetDataRoute", "a00059.html#ga1ef9c339bf1ac795d7e5f3c42cebafb7", null ],
    [ "SGTL_SetProtocol", "a00059.html#ga8087efbfa0ae9c2644d6191f441d9df0", null ],
    [ "SGTL_SetMasterSlave", "a00059.html#ga872cb128c9d0445c60dee6dbc044c7b3", null ],
    [ "SGTL_SetVolume", "a00059.html#ga88af855c5959f6d814bd8f8327e168d5", null ],
    [ "SGTL_GetVolume", "a00059.html#ga6d0af6998eff44ee5765988e05d68434", null ],
    [ "SGTL_SetMute", "a00059.html#ga4c3a087636393265417c9435b6fc57c2", null ],
    [ "SGTL_EnableModule", "a00059.html#ga51bf307e712104f5942d4cf64c60e624", null ],
    [ "SGTL_DisableModule", "a00059.html#ga26a3dba16af7a79e072f71d179dc00e6", null ],
    [ "SGTL_Deinit", "a00059.html#ga27221640262b10948a03f3178e379814", null ],
    [ "SGTL_ConfigDataFormat", "a00059.html#ga120c853dc3a86f5c70c4fbef309b6ef5", null ],
    [ "SGTL_SetPlay", "a00059.html#ga3052a63c17bdfdfeac94d1011434af5d", null ],
    [ "SGTL_SetRecord", "a00059.html#gaf929ad37a6dd584cd5f17d52560ef7df", null ],
    [ "SGTL_WriteReg", "a00059.html#ga1f0eb0cad0476f34f65811b99d58752f", null ],
    [ "SGTL_ReadReg", "a00059.html#gad044b5a578bac8480229730d610f22b6", null ],
    [ "SGTL_ModifyReg", "a00059.html#ga43f1ac7cec503ad6e6ea178b6fb691ac", null ]
];