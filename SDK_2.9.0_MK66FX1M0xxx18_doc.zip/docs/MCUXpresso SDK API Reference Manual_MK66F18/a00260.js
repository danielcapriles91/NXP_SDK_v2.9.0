var a00260 =
[
    [ "FSL_I2C_FREERTOS_DRIVER_VERSION", "a00260.html#ga8a57a810d1c6632d3bf7dd2ea4e76ae5", null ],
    [ "I2C_RTOS_Init", "a00260.html#ga2d8b0de9d5d807257ac91df157233cae", null ],
    [ "I2C_RTOS_Deinit", "a00260.html#gabe3dc27604637a77cba04967097defb2", null ],
    [ "I2C_RTOS_Transfer", "a00260.html#ga0b090779ab62f02149066a2325feb868", null ]
];