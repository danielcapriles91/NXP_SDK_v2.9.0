var a00067 =
[
    [ "uart_edma_handle_t", "a00067.html#a00284", [
      [ "callback", "a00067.html#a254f41d5cf70fff13fd2b1bcd902c2b6", null ],
      [ "userData", "a00067.html#a234d609cec5123bf352a4fa3f806375b", null ],
      [ "rxDataSizeAll", "a00067.html#af0b202b2076e0542e91592ff95f5f517", null ],
      [ "txDataSizeAll", "a00067.html#a9903cca60c9cc79aaf4b7d6156b3f1ba", null ],
      [ "txEdmaHandle", "a00067.html#ad339b242805d2cb1d2aff0b12315598d", null ],
      [ "rxEdmaHandle", "a00067.html#a74ce23f0dfe586490d83b754a6b3b558", null ],
      [ "nbytes", "a00067.html#a42e9b4098a1a5bc1891aad20e1e36a8a", null ],
      [ "txState", "a00067.html#a0e8aef6bbb90253640829077217256d4", null ],
      [ "rxState", "a00067.html#ac9828f820ff1898b81662915af78784b", null ]
    ] ],
    [ "FSL_UART_EDMA_DRIVER_VERSION", "a00067.html#gaeaa7d605207eb7c532593f3b719078f1", null ],
    [ "uart_edma_transfer_callback_t", "a00067.html#ga1fbe483dd5c3f3d55eb6d15b1b9582da", null ],
    [ "UART_TransferCreateHandleEDMA", "a00067.html#gaf0c9b2e173615b29024177d6b23eba13", null ],
    [ "UART_SendEDMA", "a00067.html#ga93b7de7f76c97da666960d1edf426f8e", null ],
    [ "UART_ReceiveEDMA", "a00067.html#ga45666dbc1751a6a5a764081c64adedcf", null ],
    [ "UART_TransferAbortSendEDMA", "a00067.html#gaa408be3578de10ad1c282d5641d5ccbb", null ],
    [ "UART_TransferAbortReceiveEDMA", "a00067.html#ga4ad0f15f9fe7444f9c8b6d8e11ec1d09", null ],
    [ "UART_TransferGetSendCountEDMA", "a00067.html#ga3bc277a61e91956d9f576b6bc2b4f229", null ],
    [ "UART_TransferGetReceiveCountEDMA", "a00067.html#ga40cd67bb3e5c1ef21c5424cc8bef1d23", null ]
];