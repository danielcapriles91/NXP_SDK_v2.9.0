var a00031 =
[
    [ "i2c_master_edma_handle_t", "a00031.html#a00276", [
      [ "transfer", "a00031.html#a3766bc4cc29984a5df623edcbe1b9ca9", null ],
      [ "transferSize", "a00031.html#aebd195813157bfa7d42438f90c1055e0", null ],
      [ "nbytes", "a00031.html#a12372a02e497b34e78291de9718d9686", null ],
      [ "state", "a00031.html#a1881cce73748c6ec2865369ddfc7267a", null ],
      [ "dmaHandle", "a00031.html#a6e2f4a49072588927fba93dbd91541f3", null ],
      [ "completionCallback", "a00031.html#ad9b0ed66d282416716070f0e0d464c8d", null ],
      [ "userData", "a00031.html#aa190dc1f8bbea43a9ad7f5f0b6de9859", null ]
    ] ],
    [ "FSL_I2C_EDMA_DRIVER_VERSION", "a00031.html#ga259846af2f1bd57728041a16a202fa04", null ],
    [ "i2c_master_edma_transfer_callback_t", "a00031.html#ga8e6dcec2d47eae5e1e5e2bb6c40b7e57", null ],
    [ "I2C_MasterCreateEDMAHandle", "a00031.html#ga2b04a3e7d9cc4772f0442b52319c9d8b", null ],
    [ "I2C_MasterTransferEDMA", "a00031.html#ga051fb0ab265d006085ae1bab58947554", null ],
    [ "I2C_MasterTransferGetCountEDMA", "a00031.html#ga5f5e384fc8e7051293b1278fb1526fa2", null ],
    [ "I2C_MasterTransferAbortEDMA", "a00031.html#gaba53231e4fee0aadb9cd0fbeeb61492a", null ]
];