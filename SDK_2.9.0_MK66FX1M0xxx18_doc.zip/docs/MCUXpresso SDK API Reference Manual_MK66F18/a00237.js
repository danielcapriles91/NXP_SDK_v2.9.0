var a00237 =
[
    [ "ftfx adapter", "a00238.html", null ],
    [ "FTFx_DRIVER_IS_FLASH_RESIDENT", "a00237.html#ga0989b400fb1c51918760be1e367bcbc1", null ],
    [ "FTFx_DRIVER_IS_EXPORTED", "a00237.html#gabda161d7ab04497e8004c067f5d849e0", null ],
    [ "FTFx_DRIVER_HAS_FLASH1_SUPPORT", "a00237.html#ga9edaa96c9680f9ff391a3ddf9fef9cf1", null ],
    [ "FTFx_FLASH1_HAS_PROT_CONTROL", "a00237.html#gadaaa8d049e882a02f6de4d62511de3f6", null ],
    [ "FTFx_FLASH1_HAS_XACC_CONTROL", "a00237.html#ga580a13d61af6e50d59aaa2d2adb84cc9", null ]
];