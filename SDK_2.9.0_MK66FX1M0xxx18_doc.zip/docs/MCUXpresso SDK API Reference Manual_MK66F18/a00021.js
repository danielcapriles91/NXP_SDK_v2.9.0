var a00021 =
[
    [ "ewm_config_t", "a00021.html#a00328", [
      [ "enableEwm", "a00021.html#a9fc625647ba94efff761a19ea25dedae", null ],
      [ "enableEwmInput", "a00021.html#a48b7c11c26b8b3a1843bd78e9bd3124c", null ],
      [ "setInputAssertLogic", "a00021.html#a824557f8134c17a6cfea99f510704127", null ],
      [ "enableInterrupt", "a00021.html#a59ced8270a61599dc2087649a0881403", null ],
      [ "compareLowValue", "a00021.html#ab0c9acea46f2d29c2a64b024dcbff24e", null ],
      [ "compareHighValue", "a00021.html#aecf428ef0d0ada1bb492fea9e8edbfc4", null ]
    ] ],
    [ "FSL_EWM_DRIVER_VERSION", "a00021.html#ga13413f9927ed720755dc3e98f77ecba2", null ],
    [ "_ewm_interrupt_enable_t", "a00021.html#gaf1f0321cab3227a897b2e2475ceaec5f", [
      [ "kEWM_InterruptEnable", "a00021.html#ggaf1f0321cab3227a897b2e2475ceaec5fa5bd5d6fb4ae17d0173bda608f54fa0e7", null ]
    ] ],
    [ "_ewm_status_flags_t", "a00021.html#ga8713ae33b98d07c7a0aeae8bf78432d1", [
      [ "kEWM_RunningFlag", "a00021.html#gga8713ae33b98d07c7a0aeae8bf78432d1a4d8e2380358f82522dc60a6ca08a55d3", null ]
    ] ],
    [ "EWM_Init", "a00021.html#gafe731b0ab2d0c9f566784a1d6ee722cc", null ],
    [ "EWM_Deinit", "a00021.html#ga4e3101bd8ccb2c11b563819e21058b28", null ],
    [ "EWM_GetDefaultConfig", "a00021.html#gac87adab8a628260058e8bee7b849ec67", null ],
    [ "EWM_EnableInterrupts", "a00021.html#ga01dcefd3eeaf15ba50ab43b95bb3ef5a", null ],
    [ "EWM_DisableInterrupts", "a00021.html#gacb4ba8a7f7e0bedd5d8acf2e5e185f46", null ],
    [ "EWM_GetStatusFlags", "a00021.html#gacfb200abe644ca56e7be42fac09d6f6a", null ],
    [ "EWM_Refresh", "a00021.html#gaf12c54c9b4bab2c1fa19eb1e81e501a0", null ]
];