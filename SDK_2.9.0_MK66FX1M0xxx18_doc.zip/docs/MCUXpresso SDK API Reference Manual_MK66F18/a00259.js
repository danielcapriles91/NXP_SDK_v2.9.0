var a00259 =
[
    [ "FSL_DSPI_FREERTOS_DRIVER_VERSION", "a00259.html#ga41f8f6bc41ef3563fd02bf4cce4a8e7e", null ],
    [ "DSPI_RTOS_Init", "a00259.html#ga991f39c326c4343df80ec09d759cb28c", null ],
    [ "DSPI_RTOS_Deinit", "a00259.html#gaad03d7e97b27114bde3b5fa74c5caf2d", null ],
    [ "DSPI_RTOS_Transfer", "a00259.html#ga0cde6422d3e35956a6ee0505783d357b", null ]
];