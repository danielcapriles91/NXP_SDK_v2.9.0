var a00053 =
[
    [ "sdmmchost_pwr_card_t", "a00053.html#a00424", [
      [ "powerOn", "a00053.html#a5f92780db6b7b671b2e278fb37f086a3", null ],
      [ "powerOnDelay_ms", "a00053.html#a2c042fa348f296d9a00afb5ae8a5f855", null ],
      [ "powerOff", "a00053.html#ac34f526578869ddf61e0c912d583476a", null ],
      [ "powerOffDelay_ms", "a00053.html#aec08e8db9fb47c742556038e650521db", null ]
    ] ],
    [ "sdmmchost_t", "a00053.html#a00425", [
      [ "hostController", "a00053.html#ad49c6e834e9337552a3fb14bee2b8ceb", null ],
      [ "dmaDesBuffer", "a00053.html#afdbf757e35a244a36abd144ef6a221c7", null ],
      [ "dmaDesBufferWordsNum", "a00053.html#a4b1c5755001081eb0846e05bc7ae220d", null ],
      [ "handle", "a00053.html#a23dd0b191911fe44859c8c686d8dbf30", null ],
      [ "hostEvent", "a00053.html#a11341f23f4880014e3434831ecfcbfc5", null ],
      [ "cd", "a00053.html#a5eac770d59a0ce28e585fe187de8a584", null ],
      [ "cardInt", "a00053.html#ac13e3f3fbadf990f727778cd1e79ed3b", null ]
    ] ],
    [ "FSL_SDMMC_HOST_ADAPTER_VERSION", "a00053.html#gab7f416230cd008bf4453aca9e4ae6623", null ],
    [ "SDMMCHOST_SUPPORT_HIGH_SPEED", "a00053.html#ga51ef85092e4c145fd0c3a422df20aa93", null ],
    [ "SDMMCHOST_INSTANCE_SUPPORT_8_BIT_WIDTH", "a00053.html#ga27fe2eca22de5770ae743c1e07bc1084", null ],
    [ "SDMMCHOST_DMA_DESCRIPTOR_BUFFER_ALIGN_SIZE", "a00053.html#ga9910e59364c563ce607bcd4b4b408fbb", null ],
    [ "sdmmchost_transfer_t", "a00053.html#ga5dde42139b5598e96b056f8138e4f575", null ],
    [ "sdmmchost_pwr_t", "a00053.html#gae6c9fa0b6cb785c1aeb2aa4a0204de6a", null ],
    [ "_sdmmchost_endian_mode", "a00053.html#gaf0790af3dd4f5150d70749a16b8a3273", [
      [ "kSDMMCHOST_EndianModeBig", "a00053.html#ggaf0790af3dd4f5150d70749a16b8a3273a4ed3ac858d9b99252a49ca7a297d2dd0", null ],
      [ "kSDMMCHOST_EndianModeHalfWordBig", "a00053.html#ggaf0790af3dd4f5150d70749a16b8a3273a2394f707bc8124fa714e61e0d9748264", null ],
      [ "kSDMMCHOST_EndianModeLittle", "a00053.html#ggaf0790af3dd4f5150d70749a16b8a3273accb3b8b837fb20c01c79a99364ca0138", null ]
    ] ],
    [ "SDMMCHOST_SetCardBusWidth", "a00053.html#ga6a2f4160b4f2bf3a24c0a9e85f652cac", null ],
    [ "SDMMCHOST_SendCardActive", "a00053.html#ga3167687798418ad802388c549a4dc79e", null ],
    [ "SDMMCHOST_SetCardClock", "a00053.html#gaed911872439a396900e606d88ec2f639", null ],
    [ "SDMMCHOST_IsCardBusy", "a00053.html#gab3ab76c607654db1629f1bbaf773c2c3", null ],
    [ "SDMMCHOST_StartBoot", "a00053.html#ga1b1a9d28ed22d8b7496372b0d1b2d068", null ],
    [ "SDMMCHOST_ReadBootData", "a00053.html#ga67013c224293f28edf35bbd645f56171", null ],
    [ "SDMMCHOST_EnableBoot", "a00053.html#ga95c2985329c39dd313a8ae3330dafbcf", null ],
    [ "SDMMCHOST_EnableCardInt", "a00053.html#ga02e31cfbe66648fc70cb5ad1ad8d4e81", null ],
    [ "SDMMCHOST_CardIntInit", "a00053.html#ga96724bd653d1ca166314f52bd8eaf9ab", null ],
    [ "SDMMCHOST_CardDetectInit", "a00053.html#gaae33c669f37f6354c1618e4354e7a2d8", null ],
    [ "SDMMCHOST_PollingCardDetectStatus", "a00053.html#ga846a7644c956ee5533e913327cb85c3c", null ],
    [ "SDMMCHOST_CardDetectStatus", "a00053.html#gae0989b876590f6ae75709a06de205ae7", null ],
    [ "SDMMCHOST_Init", "a00053.html#ga8f316244d63b01d005de110482ca125f", null ],
    [ "SDMMCHOST_Deinit", "a00053.html#gad8070be281bdd447d149114b4445bcdc", null ],
    [ "SDMMCHOST_SetCardPower", "a00053.html#ga587da6c26c9e6401e77d083011b8e474", null ],
    [ "SDMMCHOST_TransferFunction", "a00053.html#ga62429a2a668ae8bef49352256bbc6a48", null ],
    [ "SDMMCHOST_Reset", "a00053.html#gac4d25fd8cb129e822223b868bdfa6c10", null ],
    [ "SDMMCHOST_WaitCardDetectStatus", "a00053.html#ga6a91d7919263d37e71f148ce4f8cba7c", null ],
    [ "SDMMCHOST_PowerOffCard", "a00053.html#ga78baa10b1f20d2a398b1533baad9bf95", null ],
    [ "SDMMCHOST_PowerOnCard", "a00053.html#gaa256b5bc8950722ab45172f207cc11d5", null ]
];