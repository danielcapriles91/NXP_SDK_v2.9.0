var a00052 =
[
    [ "sdmmc_osa_event_t", "a00052.html#a00423", null ],
    [ "SDMMC_OSA_EVENT_TRANSFER_CMD_SUCCESS", "a00052.html#ga40f9b09069955ad5d8745cdc54b2cf0e", null ],
    [ "SDMMC_OSA_EVENT_CARD_INSERTED", "a00052.html#ga18af4c8094d77d6b76b5a060234f66e9", null ],
    [ "SDMMC_OSA_POLLING_EVENT_BY_SEMPHORE", "a00052.html#gae92d4284e8a077044fe31155c914121b", null ],
    [ "SDMMC_OSAInit", "a00052.html#ga56578b5f06118520003c8c64845fc74e", null ],
    [ "SDMMC_OSAEventCreate", "a00052.html#ga7e27cd46ed9a2c318ed91eddf619963e", null ],
    [ "SDMMC_OSAEventWait", "a00052.html#ga4f3a1084be9f933e9113229ac4a1d0cd", null ],
    [ "SDMMC_OSAEventSet", "a00052.html#ga74712ab81ddfaba83db64fa312e478dc", null ],
    [ "SDMMC_OSAEventGet", "a00052.html#ga4041592c308b3ae1b56c443b3868cc78", null ],
    [ "SDMMC_OSAEventClear", "a00052.html#ga4910eb39c0b87f1561f5dcebf97691b5", null ],
    [ "SDMMC_OSAEventDestroy", "a00052.html#ga9590db7e4c4caa97fca6971f425a835a", null ],
    [ "SDMMC_OSADelay", "a00052.html#ga885c6a7de60f8225f903a2d991fd585a", null ]
];