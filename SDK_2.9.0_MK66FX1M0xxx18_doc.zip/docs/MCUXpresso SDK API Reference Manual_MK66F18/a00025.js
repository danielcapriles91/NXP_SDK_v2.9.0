var a00025 =
[
    [ "flexnvm_config_t", "a00025.html#a00338", null ],
    [ "flexnvm_property_tag_t", "a00025.html#gae07f31240dba85a0fc25d1775a20ceac", [
      [ "kFLEXNVM_PropertyDflashSectorSize", "a00025.html#ggae07f31240dba85a0fc25d1775a20ceacabb7c699af9d864cb78d255081ee85e6a", null ],
      [ "kFLEXNVM_PropertyDflashTotalSize", "a00025.html#ggae07f31240dba85a0fc25d1775a20ceacaf5223e949fd2bf0c8dafbe48e1b5642e", null ],
      [ "kFLEXNVM_PropertyDflashBlockSize", "a00025.html#ggae07f31240dba85a0fc25d1775a20ceaca5aa34fc2a56a4e40db25aae4789874e2", null ],
      [ "kFLEXNVM_PropertyDflashBlockCount", "a00025.html#ggae07f31240dba85a0fc25d1775a20ceaca5d42a9c0d9bab1ccb4c45b629b978ac0", null ],
      [ "kFLEXNVM_PropertyDflashBlockBaseAddr", "a00025.html#ggae07f31240dba85a0fc25d1775a20ceacaf5f1265033121d17accd8eab6c674443", null ],
      [ "kFLEXNVM_PropertyAliasDflashBlockBaseAddr", "a00025.html#ggae07f31240dba85a0fc25d1775a20ceaca4eb997109767c75237c2e1f8c69b0d0a", null ],
      [ "kFLEXNVM_PropertyFlexRamBlockBaseAddr", "a00025.html#ggae07f31240dba85a0fc25d1775a20ceaca7ea8684b57d6ecd8da49ac2b7111071b", null ],
      [ "kFLEXNVM_PropertyFlexRamTotalSize", "a00025.html#ggae07f31240dba85a0fc25d1775a20ceacaf21bffab933cd172be155edc6e3d9be8", null ],
      [ "kFLEXNVM_PropertyEepromTotalSize", "a00025.html#ggae07f31240dba85a0fc25d1775a20ceaca75da70ae8381d84ee581cb7e6b8c77e6", null ]
    ] ],
    [ "FLEXNVM_Init", "a00025.html#gac07ad15ba63f1ec86217eeb8c2df3520", null ],
    [ "FLEXNVM_DflashErase", "a00025.html#ga5fd0d2df3119387d00af533d11fa79bf", null ],
    [ "FLEXNVM_EraseAll", "a00025.html#ga83fb93b84479299ded0b9b2f881dd157", null ],
    [ "FLEXNVM_DflashProgram", "a00025.html#ga7e4d702ae57466443fe255beacdd2769", null ],
    [ "FLEXNVM_DflashProgramSection", "a00025.html#ga9f2240753d9a64060b89458fe99c769f", null ],
    [ "FLEXNVM_ProgramPartition", "a00025.html#gaa798a68df63a40895cc807e4e2ccb20f", null ],
    [ "FLEXNVM_ReadResource", "a00025.html#gac2bc489d5e79ebef2307b2c194b62a9b", null ],
    [ "FLEXNVM_DflashVerifyErase", "a00025.html#gadad21e35f543ca53898e3cb095b7e5cb", null ],
    [ "FLEXNVM_VerifyEraseAll", "a00025.html#ga4478096a94795d67d2705adb7a740fe7", null ],
    [ "FLEXNVM_DflashVerifyProgram", "a00025.html#ga37f520d7d2a26108946a3d3d310ba692", null ],
    [ "FLEXNVM_GetSecurityState", "a00025.html#ga5a1320dda499529c35382dd9f84a1a94", null ],
    [ "FLEXNVM_SecurityBypass", "a00025.html#ga16bdc534eb341b53582680955b37d740", null ],
    [ "FLEXNVM_SetFlexramFunction", "a00025.html#gafeeb6a93bcbb5e642716ee1eac0f04ad", null ],
    [ "FLEXNVM_EepromWrite", "a00025.html#ga38dc1922e79536abd0a3e9745d8da6e1", null ],
    [ "FLEXNVM_DflashSetProtection", "a00025.html#ga320d0c4cb3cdbfe304402c40e14ad036", null ],
    [ "FLEXNVM_DflashGetProtection", "a00025.html#gafcfdce5609c9cabe30bff2c586566f89", null ],
    [ "FLEXNVM_EepromSetProtection", "a00025.html#ga6544827e158a04c7cd20c6dbab9588b2", null ],
    [ "FLEXNVM_EepromGetProtection", "a00025.html#gaf0b39c76fa3dc2b137e269a1f1d5a9e8", null ],
    [ "FLEXNVM_GetProperty", "a00025.html#gac77ac9b06704e082d4b1f4bd1ed21fa0", null ]
];