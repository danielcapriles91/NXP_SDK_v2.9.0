var a00069 =
[
    [ "vref_config_t", "a00069.html#a00458", [
      [ "bufferMode", "a00069.html#aaebd388066e67761926d03b9f039a39a", null ]
    ] ],
    [ "FSL_VREF_DRIVER_VERSION", "a00069.html#gad7ba9384fd16e0483299df84f2f5d327", null ],
    [ "vref_buffer_mode_t", "a00069.html#ga791fe2db52ad2d1e359ac294a00e0c7f", [
      [ "kVREF_ModeBandgapOnly", "a00069.html#gga791fe2db52ad2d1e359ac294a00e0c7fa7bfbc7e442bd6dd4de711875938583d0", null ],
      [ "kVREF_ModeHighPowerBuffer", "a00069.html#gga791fe2db52ad2d1e359ac294a00e0c7fa92a6fb92dffd810070d7d24716df5363", null ],
      [ "kVREF_ModeLowPowerBuffer", "a00069.html#gga791fe2db52ad2d1e359ac294a00e0c7fa3279f93bb3f666981dbe39d97ab7a54a", null ]
    ] ],
    [ "VREF_Init", "a00069.html#gafa6d07d12cf6fb74c84b995f35a57c21", null ],
    [ "VREF_Deinit", "a00069.html#ga19cab0650f351da4be7ab2ac0d313d8d", null ],
    [ "VREF_GetDefaultConfig", "a00069.html#ga75fd76b8991bf283c6bfda6e9503433c", null ],
    [ "VREF_SetTrimVal", "a00069.html#gac298cc63090a16123d466eb8efc9cfe3", null ],
    [ "VREF_GetTrimVal", "a00069.html#gab6fc89e608c1ddb5b323ad8d992ccbbb", null ]
];