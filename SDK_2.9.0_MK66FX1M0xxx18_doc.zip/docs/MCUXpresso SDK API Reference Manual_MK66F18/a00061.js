var a00061 =
[
    [ "sim_uid_t", "a00061.html#a00440", [
      [ "MH", "a00061.html#a8a9d28271e85bc94589c4b92ee7a295f", null ],
      [ "ML", "a00061.html#a05017c1c227e414873909db10b99bf26", null ],
      [ "L", "a00061.html#af7412e8311468eed8eb02dcdc4d239dd", null ]
    ] ],
    [ "_sim_usb_volt_reg_enable_mode", "a00061.html#gaee3ab150f9fa307e46e89e3fa96c824e", [
      [ "kSIM_UsbVoltRegEnable", "a00061.html#ggaee3ab150f9fa307e46e89e3fa96c824ea6a5673cc751eae6d18312170da355ff8", null ],
      [ "kSIM_UsbVoltRegEnableInLowPower", "a00061.html#ggaee3ab150f9fa307e46e89e3fa96c824ea17d19742ae6a9b1f244b3390e851f29f", null ],
      [ "kSIM_UsbVoltRegEnableInStop", "a00061.html#ggaee3ab150f9fa307e46e89e3fa96c824ea088607a90c39948ece281f8d1dbb02ec", null ],
      [ "kSIM_UsbVoltRegEnableInAllModes", "a00061.html#ggaee3ab150f9fa307e46e89e3fa96c824ea06a7e0f4760eeff5f4579497870e5b1d", null ]
    ] ],
    [ "_sim_flash_mode", "a00061.html#gaedab0f53d2713b72bbfafe450a4106eb", [
      [ "kSIM_FlashDisableInWait", "a00061.html#ggaedab0f53d2713b72bbfafe450a4106eba591a1948255aa353bc94c638d3dabf4e", null ],
      [ "kSIM_FlashDisable", "a00061.html#ggaedab0f53d2713b72bbfafe450a4106ebafd17678862cb1b8f673163c3ed1607a8", null ]
    ] ],
    [ "SIM_SetUsbVoltRegulatorEnableMode", "a00061.html#ga3a3558c38a6ebdbeceb3609777f67039", null ],
    [ "SIM_GetUniqueId", "a00061.html#ga3691d99318793509be2fdc198ec7fd9e", null ],
    [ "SIM_SetFlashMode", "a00061.html#gac4bdb850b3c3da318546b4256d6a9500", null ]
];