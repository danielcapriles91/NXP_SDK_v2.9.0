##Personal Healthcare Device - Weight Scale

Personal healthcase device class (PHDC) enables USB connectivity among medical devices.

This class requires one IN and one OUT bulk endpoint. Additional endpoints can belong to either the bulk or interrupt type.
