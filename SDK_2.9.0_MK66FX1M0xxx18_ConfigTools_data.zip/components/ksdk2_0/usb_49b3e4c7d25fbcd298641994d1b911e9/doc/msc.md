##MSC RAM

The USB mass storage device class defines the protocols for file transfers between the host and the device.
The USB stack provides support for MSC class driver which implements the bulk-only transport specification and the UFI command specification.

Mass storage class interface allows USB device to be enumerated and worked with as memory drive.


