###Universal Serial Bus
USB is a fast bi-directional isochronous low-cost dynamically attachable serial interface that is an industry standard.
It provides a ubiquitous link that can be used across a wide range of peripheral-to-PC interconnects.
USB specification is maintained by the [USB Implementers Forum](https://www.usb.org/) (USB-IF).
